import java.util.Scanner;

public class lab3 {
// -----------------------------------------------------------------------------------------------------------
	//AUTHOR: Eduardo Arellano
	//FILENAME: lab3
	//SPECIFICATION: Program to calculate students over grade and determine whether they passed or fail.
	// FOR: CSE 110- Lab 3
	// TIME SPENT: 3 HOURS
	public static void main(String[] args) {
		// This scanner is prepared for you to get inputs
		Scanner scanner = new Scanner(System.in);
        // Declare three variables for HW, midterm, and final exam grades
	int homework = 0;
	int midterm = 0;
	int finalexam = 0;
		 // Declare a loop control variable i
	int i = 0;
		//Run a while loop until i>3
	while(i < 3) {
				// If I is 0, asks for the homework grade
		if(i==0) {
			//Generate a prompt "Enter your HOMEWORK grade:");
			System.out.print("Enter your HOMEWORK grade: ");
//Assign homework with int value from the scanner
			homework = scanner.nextInt();
			//If the homework value is valid (Between 0 and 100)
			if (homework >= 0 && homework <= 100) {
				//Increment the number
				i++;
			}
			//if the homework value is invalid
			else {
				//Provide prompt "[ERR] Invalid input. A Homework grade should be in [0, 100]."
				System.out.println ("[ERR] Invalid input. A homework grade should be in [0, 100].");
			}
		}
		//If i is 1, asks for the midterm exam grade
		else if (i == 1) {
			// Generate a prompt "enter your MIDTERM exam grade: "
			System.out.print("Enter your MIDTERM EXAM grade: ");
			// Assign midterm with the int value from the scanner
			midterm = scanner.nextInt();
			// if the midterm value is valid (between 0 and 100)
			if (midterm >=0 && midterm <= 100) {
			// increment the number
				i+= 1;
			}
			//if the midterm is invalid
			else {
				//Provide prompt "[ERR] Invalid input A midterm garde should be in [0,100]."
				System.out.println("[ERR] Invalid input. A mid term grade should be in [0, 100].");
			}
		}
		// if i is 2, asks for the final exam grade
		else if (i == 2) {
			// Generate a prompt "enter your final exam grade: "
		System.out.print("Enter your FINAL EXAM grade: ");
		// Assign finalexam with the input from the scanner
		finalexam = scanner.nextInt();
		// If the final exam is valid (between 0 and 200)
		if (finalexam >=0 && finalexam <=200) {
			//Increment the number
			i= i + 1;
		}
		// If finalexam is invalid
		else {
			//Provide prompt "[ERR] Invalid point. A final grade should be in [0, 200]."
			System.out.println("[ERR] Invalid point. A final garde should be in [0, 200].");
		}
		}
	}
	
	//Calculate the weighted total by the formula showed in the PDF
	double weighted_total;
	// For some reason... finalexam 25% mideterm 25% homework 25%
	weighted_total = finalexam * 0.25 + midterm * 0.25 + homework * 0.25;
	//Generate a prompt "[INFO] Student's weighted Total is "
	System.out.println("[INFO] Student's Weighted Total is "+weighted_total);
	
	// If the weighted total is more than 50
	if (weighted_total >=50) {
		//Generate a prompt "[INFO] Student PASSED the class"
		System.out.println("[INFO] Student PASSED the class");
	}
	// if the weighted total is below 50
	else {
		// Generate a prompt "[INFO] Student PASSED the class"
		System.out.println("[INFO] Student PASSED the class");
	}
	//Close the scanner
	scanner.close();
	}
}